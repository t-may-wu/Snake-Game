package snakeGame;

import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.swing.JFrame;

public class SingleFrame extends JFrame
{

	public SingleFrame(SnakeClient snakeClient)
	{
	add(new SingleP(snakeClient));
	setResizable(false);
    pack();
    setBackground(Color.BLACK);
    setTitle("Snake");
    setLocationRelativeTo(null);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
			snakeClient.connectionEnd();
			try
			{
				snakeClient.closeConnection();
			}
			catch (IOException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.exit(0);
		}
	});
	}
	
}
