package snakeGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.Serializable;

import javax.swing.JPanel;

public class Player1BoardControl extends KeyAdapter implements  Serializable
{
	
	public BoardData bd;
	public BoardPanel bp;
	
	public void setBoardData(BoardData bd)
	{
		this.bd = bd;
	}
	public BoardData getBoardData()
	{
		return bd;
	}
	
	public Player1BoardControl(BoardData bd)
	{
		this.bd = bd;
	}
	
		public void keyPressed(KeyEvent e)
		{

			
			int key = e.getKeyCode();
			if ((key == KeyEvent.VK_LEFT) && (!bd.rightArrow))
			{
				bd.move = 1;
				bd.leftArrow = true;
				bd.upArrow = false;
				bd.downArrow = false;
				bd.newmove = true;
			}
			if ((key == KeyEvent.VK_RIGHT) && (!bd.leftArrow))
			{
				bd.move = 2;
				bd.rightArrow = true;
				bd.upArrow = false;
				bd.downArrow = false;
				bd.newmove = true;
			}
			if ((key == KeyEvent.VK_UP) && (!bd.downArrow))
			{
				bd.move = 3;
				bd.upArrow = true;
				bd.rightArrow = false;
				bd.leftArrow = false;
				bd.newmove = true;
			}
			if ((key == KeyEvent.VK_DOWN) && (!bd.upArrow))
			{
				bd.move = 4;
				bd.downArrow = true;
				bd.rightArrow = false;
				bd.leftArrow = false;
				bd.newmove = true;
			}
			if ((key == KeyEvent.VK_A) && (!bd.rightArrow2))
			{
				bd.move = 1;
				bd.leftArrow2 = true;
				bd.upArrow2 = false;
				bd.downArrow2 = false;
				bd.newmove = true;
			}
			if ((key == KeyEvent.VK_D) && (!bd.leftArrow2))
			{
				bd.move = 2;
				bd.rightArrow2 = true;
				bd.upArrow2 = false;
				bd.downArrow2 = false;
				bd.newmove = true;
			}
			if ((key == KeyEvent.VK_W) && (!bd.downArrow2))
			{
				bd.move = 3;
				bd.upArrow2 = true;
				bd.rightArrow2 = false;
				bd.leftArrow2 = false;
				bd.newmove = true;
			}
			if ((key == KeyEvent.VK_S) && (!bd.upArrow2))
			{
				bd.move = 4;
				bd.downArrow2 = true;
				bd.rightArrow2 = false;
				bd.leftArrow2 = false;
				bd.newmove = true;
			}

		}

		public void setPanelHandler(BoardPanel bp)
		{
			this.bp = bp;
			
		}
	

}
