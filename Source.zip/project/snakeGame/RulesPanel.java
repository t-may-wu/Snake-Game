package snakeGame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.Serializable;

public class RulesPanel extends JPanel 
{  
  // Constructor for the main menu panel.
  public RulesPanel(RulesControl rc)
  {
     
     setLayout(null);
     
     JButton Exit = new JButton("Exit");
     Exit.addActionListener(rc);
     Exit.setBounds(239, 275, 71, 23);
     add(Exit);
      
     JLabel rulespanel = new JLabel("Rules");
     rulespanel.setFont(new Font("Tahoma", Font.PLAIN, 13));
     rulespanel.setBounds(246, 9, 57, 14);
     add(rulespanel);
     
     JTextArea rulesTextField = new JTextArea();
     rulesTextField.setBackground(SystemColor.menu);
     rulesTextField.setForeground(Color.BLACK);
     rulesTextField.setWrapStyleWord(true);
     rulesTextField.setText("The rules of this game are simple:\r\n-Guide the Snake on the screen with the up, down, left, and right keys if you are player one, and W, A, S, D keys if you are player two.\r\n-Try to get the (Red) apple as fast as you can before the other player. When you do you will grown in size!\r\n-You can move through the borders, which allows you to come out the opposite side of the border.\r\n-You can also move through your own body, but if you run in to your opponents body, you lose!\r\n-First player to eat 20 apples wins!");
     rulesTextField.setLineWrap(true);
     rulesTextField.setFont(new Font("Arial", Font.PLAIN, 13));
     rulesTextField.setEditable(false);
     rulesTextField.setBounds(10, 65, 530, 150);
     add(rulesTextField);
     
     JTextArea ThankyouTextField = new JTextArea();
     ThankyouTextField.setBackground(SystemColor.menu);
     ThankyouTextField.setFont(new Font("Arial Black", Font.PLAIN, 13));
     ThankyouTextField.setText("Thank you for playing Team 3's Snake Game. ");
     ThankyouTextField.setBounds(106, 30, 337, 34);
     add(ThankyouTextField);
     
     JTextArea extraTextField = new JTextArea();
     extraTextField.setBackground(SystemColor.menu);
     extraTextField.setWrapStyleWord(true);
     extraTextField.setLineWrap(true);
     extraTextField.setFont(new Font("Arial", Font.PLAIN, 12));
     extraTextField.setText("I hope you enjoy your time playing our game, and check out the leaderboard to see where you stack up to others.");
     extraTextField.setBounds(10, 230, 530, 39);
     add(extraTextField);
  }
}
