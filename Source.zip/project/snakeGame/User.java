package snakeGame;

import java.io.Serializable;

public class User implements Serializable
{

	public User(String username, String password, Object id)
		{
			// TODO Auto-generated constructor stub
		}

}
