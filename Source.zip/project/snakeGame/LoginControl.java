package snakeGame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.Serializable;

public class LoginControl implements ActionListener,  Serializable
{
	// Private data fields for the container and chat client.
	public JPanel container;
	private SnakeClient snakeclient; 


	// Constructor for the login controller.
	public LoginControl(JPanel container, SnakeClient snakeclient)
	{
		this.container = container;
		this.snakeclient = snakeclient; 
		this.snakeclient.setHandler(this);

	}

	// Handle button clicks.
	public void actionPerformed(ActionEvent ae)
	{
		// Get the name of the button clicked.
		String command = ae.getActionCommand();

		// The Cancel button takes the user back to the initial panel.
		if (command == "Create New Account")
		{ 
			LoginPanel loginPanel = (LoginPanel)container.getComponent(0);
			CreateAccountData data = new CreateAccountData(loginPanel.getUsername(), loginPanel.getPassword());

			// Check the validity of the information locally first.
			if (data.getUsername().equals("") || data.getPassword().equals(""))
			{
				displayError("You must enter a username and password.");
				return;
			}
			else if(data.getPassword().length()<6)
			{
				displayError("You must have a password that contains at least 6 characters");
				return;
			}
			else {
				try
				{
					snakeclient.sendToServer(data);
				} catch (IOException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}    

			}
		}

		// The Submit button submits the login information to the server.
		else if (command == "Submit")
		{
			// Get the username and password the user entered.
			LoginPanel loginPanel = (LoginPanel)container.getComponent(0);
			LoginData data = new LoginData(loginPanel.getUsername(), loginPanel.getPassword());

			// Check the validity of the information locally first.
			if (data.getUsername().equals("") || data.getPassword().equals(""))
			{
				displayError("You must enter a username and password.");
				return;
			}else {

				try
				{
					snakeclient.sendToServer(data);
				} catch (IOException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}    

			}
		}
		else if(command == "Exit")
		{
			try
			{

				snakeclient.connectionEnd();
				snakeclient.closeConnection();
				System.exit(0);
			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	public void loginSuccess()
	{

	}

	public void displayError(String error)
	{
		LoginPanel loginPanel = (LoginPanel)container.getComponent(0);
		loginPanel.setError(error);
	}
}
