package snakeGame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.Serializable;

public class MainMenuControl implements ActionListener
{
  // Private data fields for the container and chat client.
  private JPanel container;
  private LoginControl lc;
  public ClientGUI clientGUI;
  public SnakeClient snakeclient;
  public LeaderboardControl lbc;
  
  // Constructor for the login controller.
  public MainMenuControl(JPanel container, LoginControl lc, ClientGUI clientGUI, SnakeClient snakeclient, LeaderboardControl lbc)
  {
    this.container = container;
   this.lc = lc;
   this.clientGUI = clientGUI;
   this.snakeclient = snakeclient;
   this.lbc = lbc;
   
  }
  
  // Handle button clicks.
  public void actionPerformed(ActionEvent ae)
  {
    // Get the name of the button clicked.
    String command = ae.getActionCommand();

    // The Cancel button takes the user back to the initial panel.
    if (command == "Sign Out")
    {
      
      Error error = new Error("","blank");
      lc.displayError(error.getMessage());
      CardLayout cardLayout = (CardLayout)container.getLayout();
      cardLayout.show(container, "1");
      
    }

    // The Submit button submits the login information to the server.
    else if (command == "Rules")
    {    
        CardLayout cardLayout = (CardLayout)container.getLayout();
        cardLayout.show(container, "3");
    }
    
    else if (command == "LeaderBoard")
    {
//    	
    	LeaderBoardData lbd = new LeaderBoardData("stuff","stuff","stuff");
    	try
		{
			snakeclient.sendToServer(lbd);
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    else if (command == "Play")
    {
    	
    	clientGUI.setVisible(false);
    	
		try
		{
			snakeclient.sendToServer(false);
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
   }  
}

