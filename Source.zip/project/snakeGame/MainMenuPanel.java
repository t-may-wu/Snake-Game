package snakeGame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.Serializable;

public class MainMenuPanel extends JPanel 
{ 
  // Constructor for the main menu panel.
  public MainMenuPanel(MainMenuControl mmc)
  {
      
      // Create a panel for the rules button.
     // JPanel buttonPanel = new JPanel();
      JButton play = new JButton("Play");
      play.addActionListener(mmc);    
     // buttonPanel.add(play);
      
   // Create a panel for the rules button.
     // JPanel buttonPanel2 = new JPanel();
      JButton rules = new JButton("Rules");
      rules.addActionListener(mmc);    
     // buttonPanel.add(rules);
      
   // Create a panel for the rules button.
     // JPanel buttonPanel3 = new JPanel();
      JButton LeaderBoard = new JButton("LeaderBoard");
      LeaderBoard.addActionListener(mmc);    
     // buttonPanel.add(LeaderBoard);
      
   // Create a panel for the rules button.
     // JPanel buttonPanel4 = new JPanel();
      JButton Exit = new JButton("Sign Out");
      Exit.addActionListener(mmc);    
     // buttonPanel.add(Exit);
      

      // Arrange the panels in a grid.
      JPanel grid = new JPanel(new GridLayout(0, 1, 10, 10));
      grid.add(play);
      grid.add(rules);
      grid.add(LeaderBoard);
      grid.add(Exit);
      this.add(grid);


  }
}