package snakeGame;

import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
public class DatabaseFile 
{
  private Connection conn;
  //Add any other data fields you like �C at least a Connection object is mandatory
  Statement stmt;
  ResultSet rs;
  ResultSetMetaData rmd;
  private boolean checkCreateAccount = true;
  private boolean checkLogin = false;
  public DatabaseFile()
  {
    //Add your code here

    
    //Read properties file
    Properties prop = new Properties();
    
    FileInputStream fis = null;
    try
    {
      fis = new FileInputStream("snakeGame/db.properties");
    } catch (FileNotFoundException e)
    {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    try
    {
      prop.load(fis);
    } catch (IOException e)
    {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    String url = prop.getProperty("url");
    String user = prop.getProperty("user");
    String pass = prop.getProperty("password");
    
  
    try
    {
      //Perform the Connection
      conn = DriverManager.getConnection(url,user,pass);
        
    } catch (SQLException e)
    {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  
   
  }
  
  public ArrayList<String> query(String query, String q)
  {
    checkCreateAccount = true;
    checkLogin = false;
    //Add your code here
    ArrayList<String> data = new ArrayList<String>();

    
      try
      {
      //Create a statement
        stmt=conn.createStatement();
      //Execute a query
        rs=stmt.executeQuery(query);
      //Get metadata about the query
        rmd = rs.getMetaData();
      //Get the # of columns
        int no_columns = rmd.getColumnCount();
      
        //Get a column name
        String name = rmd.getColumnName(1);
        if(q == "u")
        {
        //Fetch each row (use numeric numbering
        while(rs.next()) 
        {
        	for(int i = 1; i<= no_columns; i++)
        	{
        		data.add(rs.getString(i));
        	}
          checkCreateAccount = false;
          checkLogin = true;
          
        }
        }
        else 
        {
        	while(rs.next()) 
            {
            	
            		data.add(rs.getString(1));
            		java.sql.Time s = rs.getTime(2);
            		data.add(s.toString());
            		data.add(rs.getString(3));
            	
              checkCreateAccount = false;
              checkLogin = true;
              
            }
        }
        //conn.close(); 
      } catch (SQLException e)
      {
        // TODO Auto-generated catch block
        checkCreateAccount= false;
        e.printStackTrace();
      }
      if (data.size() > 0) {
        
      return data;
    
      }
    else {
      return null;
      
    }

  }

  public boolean executeDML(String dml)
  {
    
    //Add your code here
    try
    {
      //Create a statement
      stmt=conn.createStatement();
      stmt.execute(dml);

      //conn.close();
    } catch (Exception e)
    {
      // TODO: handle exception
      e.printStackTrace();
      return false;
    }
    
    return true;
  }
  public boolean checkCreateAccount() {
    return checkCreateAccount;
  }
  public boolean checkLogin() {
    return checkLogin;
  }
}

