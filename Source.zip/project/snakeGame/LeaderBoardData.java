package snakeGame;

import java.io.Serializable;

public class LeaderBoardData implements Serializable{
	
	private Long id;
	private String username;
	private String time;
	private String gamePlayed;
	
	public void setId(Long id)
	{
		this.id = id;
	}
	public Long getId()
	{
		return id;
	}
	
	// Setter for Username
	public void setUsername(String username)
	{
		this.username = username;
	}
	
	//getter for Username
	public String getUsername() 
	{
	   return username;
	}
	
	//setter for win rate
	public void setTime(String time)
	{
		 this.time = time;
	}
	
	//get for win rate
	public String getTime()
	{
		return time;
	}
	
	//setter for games won
	public void setgameWon(String GameWon)
	{
		this.gamePlayed = GameWon;
	}
	
	//get games won
	public String getgamesWon()
	{
		return gamePlayed;
	}
	
	
	// Constructor that initializes the Username, WinRate and GamesWon
	public LeaderBoardData(String username, String time, String gameWon)
	{
		setUsername(username);
		setTime(time);
		setgameWon(gameWon);
	}
}
