package snakeGame;

import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JFrame;

public class BoardFrame extends JFrame implements Serializable
{
	public BoardData bd;
	public Player1BoardControl bc;
	public BoardPanel bp;
	public SnakeClient snakeclient;
	
	public BoardFrame(BoardPanel bp, SnakeClient snakeClient)
	{
		this.bp = bp;
		this.snakeclient = snakeClient;
//		this.bp = new BoardPanel(bc,bc.bd);
		bp.setVisible(true);
		add(bp);
		
		setResizable(false);
	    pack();
	    setBackground(Color.BLACK);
	    setTitle("Snake");
	    setLocationRelativeTo(null);
	    this.setVisible(true);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	    addWindowListener(new WindowAdapter() {
	        public void windowClosing(WindowEvent e) {
	        	snakeclient.connectionEnd();
				try
				{
					snakeclient.closeConnection();
				}
				catch (IOException e1)
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(0);
	        }
	    });
	}

	public BoardPanel getBp()
	{
		return bp;
	}

	public void setBp(BoardPanel bp)
	{
		this.bp = bp;
	}

	public BoardData getBd()
	{
		return bd;
	}

	public void setBoardata(BoardData bd)
	{
		this.bd = bd;
	}
	
}
	
	

