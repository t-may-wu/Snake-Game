package snakeGame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.Serializable;

public class RulesControl implements ActionListener
{
  // Private data fields for the container and chat client.
  private JPanel container;
  
  
  
  // Constructor for the login controller.
  public RulesControl(JPanel container)
  {
    this.container = container;
   
   
  }
  
  // Handle button clicks.
  public void actionPerformed(ActionEvent ae)
  {
    // Get the name of the button clicked.
    String command = ae.getActionCommand();

    // The Cancel button takes the user back to the initial panel.
    if (command == "Exit")
    {
      CardLayout cardLayout = (CardLayout)container.getLayout();
      cardLayout.show(container, "2");
    }
   
  }
}
