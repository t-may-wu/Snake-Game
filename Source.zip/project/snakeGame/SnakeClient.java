package snakeGame;

import java.awt.CardLayout;
import ocsf.server.ConnectionToClient;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.JFrame;

import ocsf.client.AbstractClient;

public class SnakeClient extends AbstractClient implements Serializable
{
	public LoginControl lc;
	public JFrame sp;
	public BoardData bd;
	public Long id;
	public Player1BoardControl bc;
	public BoardFrame bf;
	public boolean createdPanel = false;
	public BoardPanel bp;
	public ClientGUI cgi;
	private Player1BoardControl bc1;




	public SnakeClient(String address, int port)
	{
		super(address, port);
		sp = new SingleFrame(this);
		//		bc = new Player1BoardControl();


	}

	@Override
	public void handleMessageFromServer(Object arg0)
	{
		if(arg0 instanceof Error)
		{
			Error error = (Error)arg0;
			lc.displayError(error.getMessage());
			CardLayout cardLayout = (CardLayout)lc.container.getLayout();
			cardLayout.show(lc.container, "1");
		}
		else if(arg0 instanceof ArrayList)
		{
			ArrayList<String> result = (ArrayList<String>) arg0;
			LeaderboardPanel lbp = (LeaderboardPanel) lc.container.getComponent(3);
			int max =0;
			if(result.size() > 15)
			{
				max = 16;
			}
			else
			{
				max = result.size();
			}
			for(int i = 0; i < max; i=i+3)
			{
				if(i == 0)
				{
					lbp.setUserText(result.get(i), result.get(i+1), result.get(i+2));
				}
				if(i == 3)
				{
					lbp.setUser1Text(result.get(i), result.get(i+1), result.get(i+2));
				}
				if(i == 6)
				{
					lbp.setUser2Text(result.get(i), result.get(i+1), result.get(i+2));
				}
				if(i == 9)
				{
					lbp.setUser3Text(result.get(i), result.get(i+1), result.get(i+2));
				}
				if(i == 12)
				{
					lbp.setUser4Text(result.get(i), result.get(i+1), result.get(i+2));
				}
				if(i == 15)
				{
					lbp.setUser5Text(result.get(i), result.get(i+1), result.get(i+2));
				}
			}
			CardLayout cardLayout = (CardLayout)lc.container.getLayout();
			cardLayout.show(lc.container, "4");
		}
		else if(arg0 instanceof String)
		{
			String panel = (String) arg0;
			if(panel.equals("LoginSuccessful"))
			{
				CardLayout cardLayout = (CardLayout)lc.container.getLayout();
				cardLayout.show(lc.container, "2");
			}
			else if(panel.equals("CreateAccountSuccessful"))
			{
				Error error = new Error("Account Create Succesful! Have fun!","ACS");
				lc.displayError(error.getMessage());

			}
		}
		else if(arg0 instanceof Boolean)
		{
			//			BoardData bd = (BoardData) arg0;

			//				if(!bd.getTwoplayers())
			//				{
			sp.setVisible(true);
			try
			{
				Thread.sleep(5000);
			}
			catch (InterruptedException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try
			{
				this.sendToServer(false);
			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}				

		}
		else if(arg0 instanceof Long)
		{
			sp.setVisible(false);
			long startTime = 0;
			boolean gameon = true;
			while(gameon)
			{
				if(bf == null)
				{
					startTime = System.currentTimeMillis();
					bd = new BoardData();
					bc1 = new Player1BoardControl(bd);
					bp = new BoardPanel(bc1,bd);
					bf = new BoardFrame(bp,this);

				}
				bp.initBoard(startTime);
				if(!bp.bd.Ingame)
				{
					Long time = bp.time;
					gameon = false;
					bf.setVisible(false);
					bf = null;
					try
					{
						this.sendToServer(time);
					}
					catch (IOException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		}

		else if(arg0 instanceof Integer)
		{
			this.cgi.setVisible(true);
			CardLayout cardLayout = (CardLayout)lc.container.getLayout();
			cardLayout.show(lc.container, "2");
		}
	}






	public void connectionEnd()
	{
		try
		{
			super.sendToServer("END");
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void connectionException (Throwable exception) 
	{
		//Add your code here
	}
	public void connectionEstablished()
	{
		//Add your code here
	}

	public void setHandler(LoginControl loginControl)
	{
		lc = loginControl;
	}

}
