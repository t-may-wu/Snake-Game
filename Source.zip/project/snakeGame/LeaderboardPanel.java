package snakeGame;

import java.awt.*;
import java.io.Serializable;

import javax.swing.*;


public class LeaderboardPanel extends JPanel 
{
	
	public JLabel user1;
	public JLabel user1Time;
	public JLabel user1Won;
	public JLabel user2;
	public JLabel user2Time;
	public JLabel user2Won;
	public JLabel user3;
	public JLabel user3Time;
	public JLabel user3Won;
	public JLabel user4;
	public JLabel user4Time;
	public JLabel user4Won;
	public JLabel user5;
	public JLabel user5Time;
	public JLabel user5Won;
	public JLabel user;
	public JLabel userTime;
	public JLabel userWon;
	
	
	
	public void setUserText(String user, String userTime, String userWon)
	{
		this.user.setText(user);
		this.userTime.setText(userTime);
		this.userWon.setText(userWon);
	}
	
	public void setUser1Text(String user, String userTime, String userWon)
	{
		this.user1.setText(user);
		this.user1Time.setText(userTime);
		this.user1Won.setText(userWon);
	}
	public void setUser2Text(String user, String userTime, String userWon)
	{
		this.user2.setText(user);
		this.user2Time.setText(userTime);
		this.user2Won.setText(userWon);
	}
	public void setUser3Text(String user, String userTime, String userWon)
	{
		this.user3.setText(user);
		this.user3Time.setText(userTime);
		this.user3Won.setText(userWon);
	}
	public void setUser4Text(String user, String userTime, String userWon)
	{
		this.user4.setText(user);
		this.user4Time.setText(userTime);
		this.user4Won.setText(userWon);
	}
	public void setUser5Text(String user, String userTime, String userWon)
	{
		this.user5.setText(user);
		this.user5Time.setText(userTime);
		this.user5Won.setText(userWon);
	}
	
	public LeaderboardPanel(LeaderboardControl lc)
	{
		
		this.setSize(550, 350);
		setLayout(null);
		JLabel lblLeaderboard = new JLabel("Leaderboard");
	    lblLeaderboard.setFont(new Font("Arial", Font.PLAIN, 16));
	    lblLeaderboard.setBounds(207, 11, 104, 32);
	    add(lblLeaderboard);
	    
	    JLabel lblUser = new JLabel("Username\r\n");
	    lblUser.setFont(new Font("Tahoma", Font.BOLD, 13));
	    lblUser.setBounds(42, 52, 69, 14);
	    add(lblUser);
	    
	    JLabel lblBestTime = new JLabel("Best Time\r\n");
	    lblBestTime.setFont(new Font("Tahoma", Font.BOLD, 13));
	    lblBestTime.setBounds(242, 52, 69, 14);
	    add(lblBestTime);
	    
	    JLabel lblGamesWon = new JLabel("Games Played");
	    lblGamesWon.setFont(new Font("Tahoma", Font.BOLD, 13));
	    lblGamesWon.setBounds(420, 52, 104, 14);
	    add(lblGamesWon);
	    
	    JLabel lbl1 = new JLabel("1.");
	    lbl1.setBounds(22, 77, 23, 14);
	    add(lbl1);
	    
	    JLabel lbl2 = new JLabel("2.");
	    lbl2.setBounds(22, 102, 23, 14);
	    add(lbl2);
	    
	    JLabel lbl3 = new JLabel("3.");
	    lbl3.setBounds(22, 127, 23, 14);
	    add(lbl3);
	    
	    JLabel lbl4 = new JLabel("4.");
	    lbl4.setBounds(22, 152, 23, 14);
	    add(lbl4);
	    
	    JLabel lbl5 = new JLabel("5.");
	    lbl5.setBounds(22, 177, 23, 14);
	    add(lbl5);
	    
	    JLabel lblYou = new JLabel("You");
	    lblYou.setBounds(18, 232, 23, 14);
	    add(lblYou);
	    
	    
	    JButton Exit = new JButton("Exit");
	    Exit.addActionListener(lc);
	    Exit.setBounds(222, 277, 89, 23);
	    add(Exit);
	    
	    JSeparator separator = new JSeparator();
	    separator.setBounds(22, 68, 488, 2);
	    add(separator);
	    
	    JSeparator separator_1 = new JSeparator();
	    separator_1.setBounds(22, 93, 488, 2);
	    add(separator_1);
	    
	    JSeparator separator_2 = new JSeparator();
	    separator_2.setBounds(22, 143, 488, 2);
	    add(separator_2);
	    
	    JSeparator separator_3 = new JSeparator();
	    separator_3.setBounds(22, 118, 488, 2);
	    add(separator_3);
	    
	    JSeparator separator_4 = new JSeparator();
	    separator_4.setBounds(22, 168, 488, 2);
	    add(separator_4);
	    
	    JSeparator separator_5 = new JSeparator();
	    separator_5.setBounds(22, 191, 488, 2);
	    add(separator_5);
	    
	    JSeparator separator_6 = new JSeparator();
	    separator_6.setBounds(22, 257, 488, 2);
	    add(separator_6);
	    
	    user1 = new JLabel("player 1");
	    user1.setBounds(42, 77, 186, 14);
	    add(user1);
	    
	    user2 = new JLabel("player 1");
	    user2.setBounds(42, 102, 186, 14);
	    add(user2);
	    
	    user3 = new JLabel("player 1");
	    user3.setBounds(42, 127, 46, 14);
	    add(user3);
	    
	    user4 = new JLabel("player 1");
	    user4.setBounds(42, 152, 46, 14);
	    add(user4);
	    
	    user5 = new JLabel("player 1");
	    user5.setBounds(42, 177, 46, 14);
	    add(user5);
	    
	    user = new JLabel("---");
	    user.setBounds(42, 232, 186, 14);
	    add(user);
	    
	    user1Time = new JLabel("99:99:99");
	    user1Time.setBounds(242, 77, 89, 14);
	    add(user1Time);
	    
	    user2Time = new JLabel("99:99:99");
	    user2Time.setBounds(242, 102, 89, 14);
	    add(user2Time);
	    
	    user3Time = new JLabel("99:99:99");
	    user3Time.setBounds(242, 127, 89, 14);
	    add(user3Time);
	    
	    user4Time = new JLabel("99:99:99");
	    user4Time.setBounds(242, 152, 89, 14);
	    add(user4Time);
	    
	    user5Time = new JLabel("99:99:99");
	    user5Time.setBounds(242, 177, 89, 14);
	    add(user5Time);
	    
	    user1Won = new JLabel("9999");
	    user1Won.setBounds(420, 77, 46, 14);
	    add(user1Won);
	    
	    user2Won = new JLabel("9999");
	    user2Won.setBounds(420, 102, 46, 14);
	    add(user2Won);
	    
	    user3Won = new JLabel("9999");
	    user3Won.setBounds(420, 127, 46, 14);
	    add(user3Won);
	    
	    user4Won = new JLabel("9999");
	    user4Won.setBounds(420, 152, 46, 14);
	    add(user4Won);
	    
	    user5Won = new JLabel("9999");
	    user5Won.setBounds(420, 177, 46, 14);
	    add(user5Won);
	    
	    userTime = new JLabel("---");
	    userTime.setBounds(242, 232, 89, 14);
	    add(userTime);
	    
	    userWon = new JLabel("----");
	    userWon.setBounds(420, 232, 46, 14);
	    add(userWon);
	}
	
}
