package snakeGame;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.Serializable;

public class CreateNewAccountControl implements ActionListener
{
  // Private data fields for the container and chat client.
  private JPanel container;
  
  
  
  // Constructor for the login controller.
  public CreateNewAccountControl(JPanel container)
  {
    this.container = container;
   
   
  }
  
  // Handle button clicks.
  public void actionPerformed(ActionEvent ae)
  {
      String command = ae.getActionCommand();

      // The Cancel button takes the user back to the initial panel.
      if (command == "Create New Account")
      {
        CardLayout cardLayout = (CardLayout)container.getLayout();
        cardLayout.show(container, "4");
      }

      // The Submit button submits the login information to the server.
      else if (command == "Cancel")
      {
          CardLayout cardLayout = (CardLayout)container.getLayout();
          cardLayout.show(container, "1"); 
//        // Get the username and password the user entered.
//        LoginPanel loginPanel = (LoginPanel)container.getComponent(1);
//        LoginData data = new LoginData(loginPanel.getUsername(), loginPanel.getPassword());
//        
//        // Check the validity of the information locally first.
//        if (data.getUsername().equals("") || data.getPassword().equals(""))
//        {
//          displayError("You must enter a username and password.");
//          return;
//        }else {
//            
//        try
//      {
//          chatclient1.sendToServer(data);
//      } catch (IOException e)
//      {
//          // TODO Auto-generated catch block
//          e.printStackTrace();
//      }    
//            
//        }
//       
      }
   
  }
}