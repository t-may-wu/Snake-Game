package snakeGame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class BoardPanel extends JPanel implements Serializable, ActionListener
{
	public SnakeClient snakeclient;
	public final int BOARD_WIDTH  = 400;
	public final int BOARD_HEIGHT = 400;
	public Timer clock;
	public int countdown;
	public long startTime;
	public long stopTime;
	public long time;
	
	public BoardData bd;
	
	
	
	public BoardPanel(Player1BoardControl bc, BoardData bd)
		{
		this.bd = bd;
		clock = new Timer(bd.INV_SPEED, this);
		bc.setPanelHandler(this);
		addKeyListener(bc);
		setLayout(null);
		setFocusable(true);
		countdown = 6;
//		this.setVisible(true);
		setPreferredSize(new Dimension(BOARD_WIDTH, BOARD_HEIGHT));
//			initBoard();
		 
		}
	public BoardPanel(Player2BoardControl bc, BoardData bd)
	{
		this.bd = bd;
		addKeyListener(bc);
		setLayout(null);
		setFocusable(true);
		
//		this.setVisible(true);
		setPreferredSize(new Dimension(BOARD_WIDTH, BOARD_HEIGHT));
	}
	

	public void initBoard(long startTime)
	{
		
		actionPerformed(new ActionEvent(this, BOARD_HEIGHT, new String()));
		this.startTime = startTime;
		try
		{
			Thread.sleep(100);
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			 	
				
	}
	
	public void paintComponent(Graphics g)
	{
		
		/*When repaint is called, this re-updates the graphics with the functions called prior (in actionpreformed() ) */
		
		super.paintComponent(g);
		super.setBackground(Color.BLACK);
		draw(g);
//		clock.stop();
		
		
	}
	private void draw(Graphics g)
	{
		if (bd.playGame)
		{
			g.setColor(Color.RED);
			g.fillOval(bd.appleX, bd.appleY, bd.DOT_SIZE, bd.DOT_SIZE);

			for (int z = 0; z < bd.p1Dots; z++)
			{
				if (z == 0)
				{
					g.setColor(Color.BLUE);
					g.fillOval(bd.p1X[z],bd.p1Y[z], bd.DOT_SIZE, bd.DOT_SIZE);
				}
				else
				{
					g.setColor(Color.BLUE);
					g.drawOval(bd.p1X[z], bd.p1Y[z], bd.DOT_SIZE, bd.DOT_SIZE);
				}
			}

			for (int z = 0; z < bd.p2Dots; z++)
			{
				if (z == 0)
				{
					g.setColor(Color.GREEN);
					g.fillOval(bd.p2X[z], bd.p2Y[z], bd.DOT_SIZE, bd.DOT_SIZE);
				}
				else
				{
					g.setColor(Color.GREEN);
					g.drawOval(bd.p2X[z],bd.p2Y[z], bd.DOT_SIZE, bd.DOT_SIZE);
				}
			}

			g.setColor(Color.WHITE);
			g.fillRect(0, 0, bd.SCORE_BOARD_WIDTH - 1, bd.SCORE_BOARD_HEIGHT);
			g.setColor(Color.RED);
			g.drawRect(0, 0, bd.SCORE_BOARD_WIDTH - 1, bd.SCORE_BOARD_HEIGHT);

			g.setColor(Color.WHITE);
			g.fillRect(bd.SCORE_BOARD_WIDTH + 1, 0, bd.SCORE_BOARD_WIDTH + 1, bd.SCORE_BOARD_HEIGHT);
			g.setColor(Color.RED);
			g.drawRect(bd.SCORE_BOARD_WIDTH + 1, 0, bd.SCORE_BOARD_WIDTH + 1, bd.SCORE_BOARD_HEIGHT);
			Toolkit.getDefaultToolkit().sync();
			drawScoreboard(g);

		}
		else
		{
			gameOver(g);
		}
	}

	
	private void gameOver(Graphics g)
	{

		Font small = new Font("Arial", Font.BOLD, 14);
		FontMetrics smallMetr = getFontMetrics(small);
		
		Font large = new Font("Impact", Font.BOLD, 25);
		FontMetrics largeMetr = getFontMetrics(large);
		

		g.setColor(Color.white);
		g.setFont(small);

		String msg = "Game Over";
		String winner = "";
		int gameoverx = (BOARD_WIDTH - smallMetr.stringWidth(msg)*3);
		int winnerx = 0;
		int gameovery = BOARD_HEIGHT /3;
		
		if (bd.p1Wins)
		{
			g.setColor(Color.BLUE);
			winner = "Player 1 Wins!";
			winnerx = (BOARD_WIDTH - largeMetr.stringWidth(winner))/2;
			g.setFont(large);
			g.drawString(winner, winnerx, gameovery*2-60);
		}
		else if (bd.p2Wins)
		{
			g.setColor(Color.GREEN);
			winner = "Player 2 Wins!";
			winnerx = (BOARD_WIDTH - largeMetr.stringWidth(winner))/2;
			g.setFont(large);
			g.drawString(winner, winnerx, gameovery*2-60);
		}
		else
		{
			g.setColor(Color.YELLOW);
			winner = "Game was a Draw!";
			winnerx = (BOARD_WIDTH - largeMetr.stringWidth(winner))/2;
			g.setFont(large);
			g.drawString(winner, winnerx, gameovery*2-60);
		}

		
		g.setColor(Color.WHITE);
		g.setFont(small);
		g.drawString(msg, gameoverx, 50);
		
		g.setFont(small);
		g.setColor(Color.WHITE);

		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		countdown--;
		String message = "Game will end and go to the main menu in: "+ countdown;
		g.drawString(message, BOARD_WIDTH - smallMetr.stringWidth(message)-50, gameovery*3 -60);
		
		
		if(countdown ==0)
		{
			this.stopTime = System.currentTimeMillis();
			this.time = this.stopTime -this.startTime;
			bd.setIngame(false);
		}
		
		

	}

	private void drawScoreboard(Graphics g)
	{
		Font small = new Font("Arial", Font.BOLD, 14);
		FontMetrics metr = getFontMetrics(small);
		g.setFont(small);
		g.setColor(Color.BLACK);

		String msg = "Player 1 score: " + (bd.p1Dots - 3);
		g.drawString(msg, (bd.SCORE_BOARD_WIDTH - metr.stringWidth(msg)) / 2, bd.SCORE_BOARD_HEIGHT / 2);
		g.setColor(Color.BLUE);
		msg = "Player 1 is Blue";
		g.drawString(msg, (bd.SCORE_BOARD_WIDTH - metr.stringWidth(msg)) / 2, bd.SCORE_BOARD_HEIGHT - metr.getHeight() / 2);

		g.setColor(Color.BLACK);

		msg = "Player 2 score: " + (bd.p2Dots - 3);
		g.drawString(msg, (bd.SCORE_BOARD_WIDTH * 3 - metr.stringWidth(msg)) / 2, bd.SCORE_BOARD_HEIGHT / 2);
		g.setColor(Color.GREEN);
		msg = "Player 2 is green";
		g.drawString(msg, (bd.SCORE_BOARD_WIDTH * 3 - metr.stringWidth(msg)) / 2,
				bd.SCORE_BOARD_HEIGHT - metr.getHeight() / 2);
	}
	

	@Override
	public void actionPerformed(ActionEvent e)
	{

		if (bd.playGame)
		{

			bd.checkApple();
			bd.checkCollision();
			bd.move();

		}
		else 
		{
			clock.setDelay(1000);
		}

		super.repaint();
	}


	public BoardData getBd()
	{
		return bd;
	}


	public void setBd(BoardData bd)
	{
		this.bd = bd;
	}
	
	

}

