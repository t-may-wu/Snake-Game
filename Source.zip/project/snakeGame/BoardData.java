package snakeGame;

import java.io.Serializable;
import java.util.ArrayList;


import javax.swing.Timer;

public class BoardData implements Serializable
{

	public BoardPanel bp;
	public Boolean twoplayers = false;
	public Boolean Ingame = true;
	public ArrayList<Long> clientslist = new ArrayList<Long>();
	
	public boolean player1Board = false;
	public boolean player2Board = false;
	
	public boolean player1Ready = false;
	public boolean player2Ready = false;
	
	public Long player1;
	public Long player2;
	
	public Integer move = 0;
	
	public final int	BOARD_WIDTH				= 400; /*Width of the board, and the X component */

	public final int	BOARD_HEIGHT			= 400; /*Height of the board, and the Y component*/

	public final int	SCORE_BOARD_HEIGHT		= 50; /*Height of the Score board, goes from 0 to 50*/

	public final int	SCORE_BOARD_WIDTH		= 200;/*Width of the Score board, goes from 0 to 200. represents only 1/2 of the scoreboard.*/

	public final int	DOT_SIZE				= 10; /*Size of the draw dots: Snake's head, Snake's body, and apple*/

	public final int	NUM_OF_DOTS_ON_BOARD	= 1600;/*Board H X W divided by DotSize H X W will give you the number of dots on a given board.*/

	public final int	RAND_POS				= 39; /*Used for creating a random point for the apple, 39  is chosen that way the position of the apple will be within the width of the board minus the dot size*/

	public int			appleX; /*For storing X component of the apple*/

	public int			appleY; /*For storing Y component of the apple*/

	public boolean		playGame				= true; /*Tells the game to continue or to end.*/
 
	public final int	INV_SPEED				= 80;/*inverse to speed. the lower the number, faster the game and vis versa.*/

	public int	p1X[]					= new int[NUM_OF_DOTS_ON_BOARD]; /*Used to store the player 1 snake X positions, for the body and the head.*/

	public int	p1Y[]					= new int[NUM_OF_DOTS_ON_BOARD]; /*Used to store the player 1 snakes Y positions, for the body and the head*/

	public int			p1Dots; /*Used to store player 1's number of dots, represents the number of dots for the body*/
	
	public int	p2X[]					= new int[NUM_OF_DOTS_ON_BOARD]; /*Same as p1X but for player 2*/

	public  int	p2Y[]					= new int[NUM_OF_DOTS_ON_BOARD]; 

	public int			p2Dots;

	public boolean		leftArrow				= false; /*Tells if player two's left key has been pressed, Represnets going left on the screen*/

	public boolean		rightArrow				= false; /*Tells if player two's right key has been pressed, Represnets going right on the screen*/

	public boolean		upArrow					= false; /*Tells if player two's up key has been pressed, Represnets going up on the screen*/

	public boolean		downArrow				= true; /*Tells if player two's down key has been pressed, Represnets going down on the screen*/

	public boolean		leftArrow2				= false; /*Tells if player two's left key has been pressed, Represnets going left on the screen*/

	public boolean		rightArrow2			= false; /*Tells if player two's right key has been pressed, Represnets going right on the screen*/

	public boolean		upArrow2				= false; /*Tells if player two's up key has been pressed, Represnets going up on the screen*/

	public boolean		downArrow2			= true; /*Tells if player two's down key has been pressed, Represnets going down on the screen*/

	public boolean		p1Wins					= false; /*Tells if player 1 won*/

	public boolean		p2Wins					= false; /*Tells if player 2 won*/

	public boolean		draw					= false; /*Tells if neither player 1 or 2 won*/
	
	public Timer		clock; /*Used to update the graphics repeatedly */
	public boolean newmove  = false;
	
	public BoardData()
	{
		/*player 1 and 2 default number of dots*/
		p1Dots = 3; 
		p2Dots = 3;
		
		/*creates the starting positions of the snake.*/
		for (int z = 0; z < p1Dots; z++)
		{
			p1X[z] = 60;
			p1Y[z] = 60- z * 10;
		}
		/*player 2 starting position of the snake*/
		for (int z = 0; z < p2Dots; z++)
		{
			p2X[z] = 300;
			p2Y[z] = 60 + z * 10;
		}
		
		placeApple();
		
//		/*creates a timer with a delay of INV_SPEED to continue updating the graphics.*/
//		clock = new Timer(INV_SPEED, this);
//		/*this starts sending action events, this inturn calls actionpreformed function.*/
//		clock.start();
	}
	
	public void placeApple()
	{
		boolean good = true;
		do
		{
			good = true;
			do
			{
				int temp = (int) (Math.random() * RAND_POS);
				appleX = (temp * 10);
			}
			while (appleX > BOARD_WIDTH);

			do
			{
				int temp = (int) (Math.random() * RAND_POS);
				appleY = (temp * 10) + SCORE_BOARD_HEIGHT;
			}
			while (appleY > BOARD_HEIGHT - DOT_SIZE);

			for (int i = p1Dots; i > 0; i--)
			{
				int a = p1X[i];
				int b = p1Y[i];

				if (a == appleX && b == appleY)
				{
					good = false;
				}
			}

			for (int i = p2Dots; i > 0; i--)
			{
				int a = p2X[i];
				int b = p2Y[i];

				if (a == appleX && b == appleY)
				{
					good = false;
				}
			}
		}
		while (!good);

	}
	
	public void checkApple()
	{

		if ((p1X[0] == appleX) && (p1Y[0] == appleY))
		{
			p1Dots++;
			placeApple();
		}
		if ((p2X[0] == appleX) && (p2Y[0] == appleY))
		{
			p2Dots++;
			placeApple();
		}
	}

	public void move()
	{

		for (int z = p1Dots; z > 0; z--)
		{
			p1X[z] = p1X[(z - 1)];
			p1Y[z] = p1Y[(z - 1)];
		}
		for (int z = p2Dots; z > 0; z--)
		{
			p2X[z] = p2X[(z - 1)];
			p2Y[z] = p2Y[(z - 1)];
		}

		if (leftArrow)
		{
			p1X[0] -= 10;
		}
		if (rightArrow)
		{
			p1X[0] += 10;
		}
		if (upArrow)
		{
			p1Y[0] -= 10;
		}
		if (downArrow)
		{
			p1Y[0] += 10;
		}

		if (leftArrow2)
		{
			p2X[0] -= 10;
		}
		if (rightArrow2)
		{
			p2X[0] += 10;
		}
		if (upArrow2)
		{
			p2Y[0] -= 10;
		}
		if (downArrow2)
		{
			p2Y[0] += 10;
		}
	}

	public void checkCollision()
	{

		if ((p1Dots - 3) >= 20)
		{
			playGame = false;
			p1Wins = true;
		}
		if ((p2Dots - 3) >= 20)
		{
			playGame = false;
			p2Wins = true;
		}

		if (p1Y[0] >= BOARD_HEIGHT)
		{
			p1Y[0] = SCORE_BOARD_HEIGHT;
		}
		if (p1Y[0] < SCORE_BOARD_HEIGHT)
		{
			p1Y[0] = BOARD_HEIGHT;
		}
		if (p1X[0] >= BOARD_WIDTH)
		{
			p1X[0] = 0;
		}
		if (p1X[0] < 0)
		{
			p1X[0] = BOARD_WIDTH;
		}

		if (p2Y[0] >= BOARD_HEIGHT)
		{
			p2Y[0] = SCORE_BOARD_HEIGHT;
		}
		if (p2Y[0] < SCORE_BOARD_HEIGHT)
		{
			p2Y[0] = BOARD_HEIGHT;
		}
		if (p2X[0] >= BOARD_WIDTH)
		{
			p2X[0] = 0;
		}
		if (p2X[0] < 0)
		{
			p2X[0] = BOARD_WIDTH;
		}

		if (p1X[0] == p2X[0] && p1Y[0] == p2Y[0])
		{
			playGame = false;
			draw = true;
		}
		else
		{
			for (int i = p1Dots; i >= 0; i--)
			{
				if (p2X[0] == p1X[i] && p2Y[0] == p1Y[i])
				{
					playGame = false;
					p1Wins = true;
				}
			}
			for (int i = p2Dots; i >= 0; i--)
			{
				if (p1X[0] == p2X[i] && p1Y[0] == p2Y[i])
				{
					playGame = false;
					p2Wins = true;
				}
			}
		}
	}

	public Boolean getTwoplayers()
	{
		return twoplayers;
	}

	public void setTwoplayers(Boolean twoplayers)
	{
		this.twoplayers = twoplayers;
	}

	public void setIngame()
	{
		if(Ingame)
		{
			Ingame = false;
		}
		else
		{
			Ingame = true;
		}
	}
	public boolean getIngame()
	{
		
		return false;
	}

	public boolean isPlayer1Ready()
	{
		return player1Ready;
	}

	public void setPlayer1Ready(boolean player1Ready)
	{
		this.player1Ready = player1Ready;
	}

	public boolean isPlayer2Ready()
	{
		return player2Ready;
	}

	public void setPlayer2Ready(boolean player2Ready)
	{
		this.player2Ready = player2Ready;
	}

	public long getPlayer1()
	{
		return player1;
	}

	public void setPlayer1(long player1)
	{
		this.player1 = player1;
	}

	public long getPlayer2()
	{
		return player2;
	}

	public void setPlayer2(long player2)
	{
		this.player2 = player2;
	}

	/**
	 * @return the appleX
	 */
	public int getAppleX()
	{
		return appleX;
	}

	/**
	 * @return the appleY
	 */
	public int getAppleY()
	{
		return appleY;
	}

	/**
	 * @return the playGame
	 */
	public boolean isPlayGame()
	{
		return playGame;
	}

	/**
	 * @return the p1X
	 */
	public int[] getP1X()
	{
		return p1X;
	}

	/**
	 * @return the p1Y
	 */
	public int[] getP1Y()
	{
		return p1Y;
	}

	/**
	 * @return the p1Dots
	 */
	public int getP1Dots()
	{
		return p1Dots;
	}

	/**
	 * @return the p2X
	 */
	public int[] getP2X()
	{
		return p2X;
	}

	/**
	 * @return the p2Y
	 */
	public int[] getP2Y()
	{
		return p2Y;
	}

	/**
	 * @return the p2Dots
	 */
	public int getP2Dots()
	{
		return p2Dots;
	}

	/**
	 * @return the leftArrow
	 */
	public boolean isLeftArrow()
	{
		return leftArrow;
	}

	/**
	 * @return the rightArrow
	 */
	public boolean isRightArrow()
	{
		return rightArrow;
	}

	/**
	 * @return the upArrow
	 */
	public boolean isUpArrow()
	{
		return upArrow;
	}

	/**
	 * @return the downArrow
	 */
	public boolean isDownArrow()
	{
		return downArrow;
	}

	/**
	 * @return the leftArrow2
	 */
	public boolean isLeftArrow2()
	{
		return leftArrow2;
	}

	/**
	 * @return the rightArrow2
	 */
	public boolean isRightArrow2()
	{
		return rightArrow2;
	}

	/**
	 * @return the upArrow2
	 */
	public boolean isUpArrow2()
	{
		return upArrow2;
	}

	/**
	 * @return the downArrow2
	 */
	public boolean isDownArrow2()
	{
		return downArrow2;
	}

	/**
	 * @return the p1Wins
	 */
	public boolean isP1Wins()
	{
		return p1Wins;
	}

	/**
	 * @return the p2Wins
	 */
	public boolean isP2Wins()
	{
		return p2Wins;
	}

	/**
	 * @return the draw
	 */
	public boolean isDraw()
	{
		return draw;
	}

	/**
	 * @param ingame the ingame to set
	 */
	public void setIngame(Boolean ingame)
	{
		Ingame = ingame;
	}
	public BoardData clone() 
	{
		BoardData bd = new BoardData();
		bd.appleX = this.appleX;
		bd.appleY = this.appleY;
		bd.clientslist = this.clientslist;
		bd.downArrow = this.downArrow;
		bd.downArrow2 = this.downArrow2;
		bd.upArrow = this.upArrow;
		bd.upArrow2 = this.upArrow2;
		bd.leftArrow = this.leftArrow;
		bd.leftArrow2 = this.leftArrow2;
		bd.rightArrow = this.rightArrow;
		bd.rightArrow2 = this.rightArrow2;
		bd.draw = this.draw;
		bd.p1Wins = this.p1Wins;
		bd.p2Wins = this.p2Wins;
		bd.Ingame = this.Ingame;
		bd.p1Dots = this.p1Dots;
		bd.p2Dots = this.p2Dots;
		bd.p1X = this.p1X;
		bd.p2X = this.p2X;
		bd.p1Y = this.p1Y;
		bd.p2Y = this.p2Y;
		bd.player1 = this.player1;
		bd.player2 = this.player2;
		bd.player1Board = this.player1Board;
		bd.player2Board = this.player2Board;
		bd.playGame = this.playGame;
		bd.twoplayers = this.playGame;

		return bd;
	}
	
	
	

}
