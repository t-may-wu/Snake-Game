package snakeGame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.Serializable;

public class ClientGUI extends JFrame 
{
 
	public SnakeClient snakeclient;
	
  // Constructor that creates the client GUI.
  public ClientGUI(String address, int port)
  {
    snakeclient = new SnakeClient(address, port); 
    snakeclient.cgi = this;
    
    try
    {
        snakeclient.openConnection();
    } catch (IOException e)
    {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
    
    
    // Set the title and default close operation.
    this.setTitle("Client");
    this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
        	snakeclient.connectionEnd();
			try
			{
				snakeclient.closeConnection();
			}
			catch (IOException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.exit(0);
        }
    });
    
    
        
    // Create the card layout container.
    CardLayout cardLayout = new CardLayout();
    JPanel container = new JPanel(cardLayout);
    
    //Create the Controllers next
    LoginControl lc = new LoginControl(container, snakeclient); //Probably will want to pass in ChatClient here
    LeaderboardControl lbc = new LeaderboardControl(container, snakeclient);
    MainMenuControl mmc = new MainMenuControl(container, lc, this, snakeclient, lbc);
    RulesControl rc = new RulesControl(container);
    
    
    
    
    // Create the four views. (need the controller to register with the Panels
   // JPanel view1 = new InitialPanel(ic);
    JPanel view1 = new LoginPanel(lc);
    JPanel view2 = new MainMenuPanel(mmc);
    JPanel view3 = new RulesPanel(rc); 
    JPanel view4 = new LeaderboardPanel(lbc);
    
    
    
    // Add the views to the card layout container.
    container.add(view1, "1");
    container.add(view2, "2");
    container.add(view3, "3");
    container.add(view4, "4");
    
   
    
    // Show the initial view in the card layout.
    cardLayout.show(container, "1");
    
    // Add the card layout container to the JFrame.
    this.add(container, BorderLayout.CENTER);

    // Show the JFrame.
    this.setSize(550, 350);
    this.setVisible(true);
  }

// Main function that creates the client GUI when the program is started.
  public static void main(String[] args)
  {
    new ClientGUI(args[0],Integer.parseInt(args[1]));
  }
  
}


