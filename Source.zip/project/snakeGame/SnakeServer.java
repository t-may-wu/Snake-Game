package snakeGame;

import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;

public class SnakeServer extends AbstractServer implements Runnable
{
	//  private DatabaseFile databaseFile;
	private boolean flag;
	private DatabaseFile databaseFile;
	private static SnakeServer server;
	private Queue<ConnectionToClient> clientqueue = new LinkedList<ConnectionToClient>();
	private ArrayList<Long> clientIngame = new ArrayList<Long>();
	private ArrayList<ConnectionToClient> clients = new ArrayList<ConnectionToClient>();
	private BoardData bd;
	private Player1BoardControl bc1;
	private BoardPanel bp;
	private BoardData masterbd = new BoardData();
	private Player2BoardControl bc2;
	private ArrayList<LoginData> users;
	private Integer userid;
	



	public SnakeServer() throws SQLException, IOException
	{
		super(8300);
		this.setTimeout(500);
		databaseFile=new DatabaseFile();
		
	}

	public SnakeServer(int port) throws SQLException, IOException
	{
		super(port);
		this.setTimeout(51234512);
		databaseFile=new DatabaseFile();
		users = new ArrayList<LoginData>();
		userid = 0;
		

	}

	public static void main(String[] args) throws SQLException, IOException
	{
		int port = Integer.parseInt(args[0]);
		int timeout =Integer.parseInt(args[1]);
		server = new SnakeServer(port);
		

		server.setPort(port);
		server.setTimeout(timeout);


		//Start listening
		try
		{
			server.listen();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//Test if listening
		if (server.isListening())
		{
			System.out.println("Server is listening");
		}
		boolean more = true;
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		System.out.println("Type 'stop' to stop and exit server\n");

		while(more)
		{
			if(in.hasNext())
			{
				String exit = in.next();

				if(exit.contentEquals("stop"))
				{
					System.exit(0);
				}
			}
		}

	}
	public void clientLeaving(ConnectionToClient arg1)
	{
		clientIngame.remove(arg1.getId());
		System.out.println("Client " + arg1.getId() + " is leaving.");
		System.out.println("Number of Client:" + (server.getNumberOfClients()-1)+"\n");
	}


	@Override
	protected void handleMessageFromClient(Object arg0, ConnectionToClient arg1)
	{

		if(arg0 instanceof String)
		{
			clientLeaving(arg1);
		}
		if (arg0 instanceof LoginData)
		{
			// Check the username and password with the database.

			LoginData data = (LoginData)arg0;
			Object result;
			String query = "select username, aes_decrypt(password,'key') from user where username = '"+data.getUsername()+"' and aes_decrypt(password,'key') = '"+data.getPassword()+"';";
			databaseFile.query(query,"u");
			if (databaseFile.checkLogin())
			{
				users.add(data);
				clientIngame.add(arg1.getId());
				clients.add(arg1);
				result = "LoginSuccessful";
				System.out.println("Client " + arg1.getId() + " successfully logged in as " + data.getUsername() + "\n");
			}
			else
			{
				result = new Error("The username and password are incorrect.", "Login");
				System.out.println("Client " + arg1.getId() + " failed to log in\n");
			}

			// Send the result to the client.
			try
			{
				arg1.sendToClient(result);
			}
			catch (IOException e)
			{
				e.printStackTrace();
				return;
			}
		}

		// If we received CreateAccountData, create a new account.
		else if (arg0 instanceof CreateAccountData)
		{
			// Try to create the account.
			CreateAccountData data = (CreateAccountData)arg0;
			Object result;
			String insertCheck = "Select username from user where username = '" + data.getUsername() + "';";
			System.out.println(insertCheck);
			databaseFile.query(insertCheck,"u");
			if (databaseFile.checkCreateAccount())
			{
				String insert = "Insert into user values(\"" + data.getUsername() +"\",aes_encrypt(\""+data.getPassword()+"\",'key'));";
				databaseFile.executeDML(insert);
				String insertRecord = "Insert into record values('"+ data.getUsername() + "', '23:59:59', 0);";
				databaseFile.executeDML(insertRecord);
				result = "CreateAccountSuccessful";
				System.out.println("Client " + arg1.getId() + " created a new account called " + data.getUsername() + "\n");
			}
			else
			{
				result = new Error("The username is already in use.", "CreateAccount");
				System.out.println("Client " + arg1.getId() + " failed to create a new account\n");
			}

			// Send the result to the client.
			try
			{
				arg1.sendToClient(result);
			}
			catch (IOException e)
			{
				return;
			}
		}

		// Need LeaderBoardData, LeaderBoardControl, and LeaderBoardData Class
		else if (arg0 instanceof LeaderBoardData)
		{
			int index = clients.indexOf(arg1);
			LoginData user = users.get(index);
			// Allocate LoginData
			


			// See if the user if logged in/is the data correct.
			String query = "Select * from record where username = '" + user.getUsername() + "';";
			ArrayList<String> userresults = databaseFile.query(query,"r");
			
			query = "Select * from record order by besttime, gamewon desc;";
			ArrayList<String> usersresults = databaseFile.query(query,"r");
						
			ArrayList<String> result = new ArrayList<String>();
			
			for(int i = 0; i < userresults.size(); i++)
			{
				result.add(userresults.get(i));
			}
			for(int i =0; i< usersresults.size(); i++)
			{
				result.add(usersresults.get(i));
			}
			try
			{
				arg1.sendToClient(result);
			}
			catch (IOException e)
			{
				return;
			}
		}
		else if(arg0 instanceof Boolean)
		{
			ConnectionToClient player = arg1;
			
				this.bd = new BoardData();
				
					try
					{
						player.sendToClient(player.getId());
					}
					catch (IOException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		}	
		else if(arg0 instanceof Long)
		{
			//time is being submitted here, need to create new leaderboard data and send it to client who will send it back.
			Long time = (Long) arg0;
			int index = clients.indexOf(arg1);
			LoginData data = users.get(index);
			String query = "select * from record where username = '"+data.getUsername()+"';";
			ArrayList<String> results = databaseFile.query(query,"r");
			LeaderBoardData lbData = new LeaderBoardData(results.get(0),results.get(1),results.get(2));
			
			Long newSeconds = (time / 1000) % 60;
	        Long newMinutes =  ((time / (1000 * 60)) % 60);
	        Long newHours =  ((time / (1000 * 60 * 60)) % 24);
			
			String OldTime = lbData.getTime();
			String[] OldTimeParse = OldTime.split(":");
			Long oldSeconds = Long.valueOf(OldTimeParse[2]);
			Long oldMinutes = Long.valueOf(OldTimeParse[1]);
			Long oldHours = Long.valueOf(OldTimeParse[0]);
			
			String Seconds = "";
			String Minutes = "";
			String Hours = "";
			if(oldHours < newHours)
			{
				Seconds = oldSeconds.toString();
				Minutes = oldMinutes.toString();
				Hours = oldHours.toString();
				
				if(Seconds.length() <2)
				{
					Seconds = "0"+Seconds;
				}
				if(Minutes.length() <2)
				{
					Minutes = "0" + Minutes;
				}
				if(Hours.length() <2)
				{
					Hours = "0" + Hours;
				}
			}
			else if (oldHours == newHours)
			{
				if(oldMinutes < newMinutes)
				{
					Seconds = oldSeconds.toString();
					Minutes = oldMinutes.toString();
					Hours = oldHours.toString();
					
					if(Seconds.length() <2)
					{
						Seconds = "0"+Seconds;
					}
					if(Minutes.length() <2)
					{
						Minutes = "0" + Minutes;
					}
					if(Hours.length() <2)
					{
						Hours = "0" + Hours;
					}
					
					
				}
				else if(oldMinutes == newMinutes)
				{
					
					if(oldSeconds>newSeconds)
					{
						Seconds = newSeconds.toString();
						Minutes = newMinutes.toString();
						Hours = newHours.toString();
						
						if(Seconds.length() <2)
						{
							Seconds = "0"+Seconds;
						}
						if(Minutes.length() <2)
						{
							Minutes = "0" + Minutes;
						}
						if(Hours.length() <2)
						{
							Hours = "0" + Hours;
						}
					}
					else if(oldSeconds < newSeconds)
					{
						Seconds = oldSeconds.toString();
						Minutes = oldMinutes.toString();
						Hours = oldHours.toString();
						
						if(Seconds.length() <2)
						{
							Seconds = "0"+Seconds;
						}
						if(Minutes.length() <2)
						{
							Minutes = "0" + Minutes;
						}
						if(Hours.length() <2)
						{
							Hours = "0" + Hours;
						}
					}
					else
					{
						Seconds = oldSeconds.toString();
						Minutes = oldMinutes.toString();
						Hours = oldHours.toString();
						
						if(Seconds.length() <2)
						{
							Seconds = "0"+Seconds;
						}
						if(Minutes.length() <2)
						{
							Minutes = "0" + Minutes;
						}
						if(Hours.length() <2)
						{
							Hours = "0" + Hours;
						}
						
					}
					
				}
				else
				{
					Seconds = newSeconds.toString();
					Minutes = newMinutes.toString();
					Hours = newHours.toString();
					
					if(Seconds.length() <2)
					{
						Seconds = "0"+Seconds;
					}
					if(Minutes.length() <2)
					{
						Minutes = "0" + Minutes;
					}
					if(Hours.length() <2)
					{
						Hours = "0" + Hours;
					}
					
				}
			}
			else
			{
				Seconds = newSeconds.toString();
				Minutes = newMinutes.toString();
				Hours = newHours.toString();
				
				if(Seconds.length() <2)
				{
					Seconds = "0"+Seconds;
				}
				if(Minutes.length() <2)
				{
					Minutes = "0" + Minutes;
				}
				if(Hours.length() <2)
				{
					Hours = "0" + Hours;
				}
				
			}
			
			lbData.setTime(Hours+Minutes+Seconds);
			
			String update = "update record set besttime = '"+lbData.getTime()+"',gamewon = gamewon +1 where username = '"+data.getUsername() +"';";
			databaseFile.executeDML(update);
			try
			{
				arg1.sendToClient(new Integer(1));
			}
			catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	protected void listeningException(Throwable exception) 
	{
		//Set information for status and log
		System.out.println("Listening Exception Occurred");
		System.out.println(exception);
		exception.printStackTrace();
		try {
			flag=false;
			this.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	//Server Started
	public void serverStarted() {
		//Set the information for status and log
		System.out.println("Server Started");
		flag=true;
	}

	//Server Stopped
	public void serverStopped() {
		if(flag) {
			//Set the information for status and log
		}
	}

	//Server Closed
	public void serverClosed() {
		if(flag) {
			flag=false;
		}
	}

	//Client Connected
	public void clientConnected(ConnectionToClient client) {
		clientqueue.add(client);
		System.out.println("Client "+client.getId() + " has connected.");
		System.out.println("Number of Client:" + server.getNumberOfClients()+"\n");

		//		try {
		//			client.sendToClient("Username: "+client.getId());
		//		} catch (IOException e) {
		//			// TODO Auto-generated catch block
		//			e.printStackTrace();
		//		}
	}

}
