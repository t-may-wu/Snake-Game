package snakeGame;


import java.io.IOException;
import java.io.Serializable;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class SingleP extends JPanel implements Serializable, ActionListener
{

	
	public SnakeClient snakeclient;
	public final int BOARD_WIDTH  = 400;
	public final int BOARD_HEIGHT = 400;
	public Timer clock;

	public SingleP(SnakeClient snakeclient)
	{
		this.snakeclient = snakeclient;
		
		setLayout(null);
//		setBackground(Color.black);
		setFocusable(true);
		setPreferredSize(new Dimension(BOARD_WIDTH, BOARD_HEIGHT));
		initSingle();
		
		
		
		
	}
	
	private void initSingle()
	{
		clock = new Timer(0, this);
		clock.start();
		
	}

	public void paintComponent(Graphics g)
	{
		/*When repaint is called, this re-updates the graphics with the functions called prior (in actionpreformed() ) */
		super.paintComponents(g);
		draw(g);
		clock.stop();
		
		
	}
	public void draw(Graphics g)
	{
		
		Font small = new Font("Arial", Font.BOLD, 14);
		FontMetrics smallMetr = getFontMetrics(small);
		g.setColor(Color.white);
		g.setFont(small);
		String msg = "Please wait for opponent..";
		int msgx = (BOARD_WIDTH - smallMetr.stringWidth(msg))/2;
		int msgy = BOARD_HEIGHT /2;
		g.drawString(msg, 50, 50);
	}

	@Override
	public void actionPerformed(ActionEvent arg0)
	{
		repaint();
	}
}
